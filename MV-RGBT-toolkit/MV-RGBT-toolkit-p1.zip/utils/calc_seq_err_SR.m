function OverlapScore = calc_seq_err_SR(results, rect_anno, exist_anno)
%     TYPE 1: Gt != None &  At != None   --> IOU
%     TYPE 2: Gt = None &  At = None     --> 1
%     TYPE 3: others, [Gt = None &  At != None] || [Gt != None &  At = None]   --> 0

seq_length = size(rect_anno, 1);

OverlapScore = zeros(seq_length,1);

for idx = 1:seq_length
%     gt_flag = exist_flag(rect_anno(idx,:));
    pred_flag = exist_flag(results(idx,:));
    gt_flag = exist_anno(idx);
    if pred_flag && gt_flag
        score = calc_iou(results(idx,:), rect_anno(idx,:));
    elseif (~pred_flag) && (~gt_flag)
        score = 1;
    else
        score = -1;
    end
    OverlapScore(idx) = score;
end

end

function flag = exist_flag(pred)

    if numel(pred) ==0 || numel(pred) ==1 || (pred(1)==0 &&pred(3)==0)
        flag = 0;
    else 
        flag = 1;
    end
end

function iou = calc_iou(A, B)
    % A,B [x1, y1, w, h]
    leftA   = A(1);
    topA = A(2);
%     rightA  = leftA + A(3) - 1;
%     bottomA    = topA + A(4) - 1;
    rightA  = leftA + A(3);
    bottomA    = topA + A(4);

    leftB   = B(:,1);
    topB = B(:,2);
%     rightB  = leftB + B(:,3) - 1;
%     bottomB    = topB + B(:,4) - 1;
	rightB  = leftB + B(:,3);
    bottomB    = topB + B(:,4);
    
    % # get the overlap rectangle
    overlap_x1 = max(leftA, leftB);
    overlap_y1 = max(topA, topB);
    overlap_x2 = min(rightA, rightB);
    overlap_y2 = min(bottomA, bottomB);
	if overlap_x2 - overlap_x1 <= 0 || overlap_y2 - overlap_y1 <= 0
        iou = 0;
    else
       areaA   = A(3) .* A(4);
       areaB   = B(3) .* B(4);
       size_intersection = (overlap_x2 - overlap_x1) * (overlap_y2 - overlap_y1);
       iou = size_intersection / (areaA + areaB - size_intersection);
    end   

%     tmp     = (max(0, min(rightA, rightB) - max(leftA, leftB))) * (max(0, min(bottomA, bottomB) - max(topA, topB)));
%     areaA   = A(3) .* A(4);
%     areaB   = B(3) .* B(4);
%     iou = tmp./(areaA + areaB -tmp);
end