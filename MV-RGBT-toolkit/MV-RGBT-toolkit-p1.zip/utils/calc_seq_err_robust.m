function [overlapScore, err_center] = calc_seq_err_robust(results, rect_anno, exist_anno, norm_dst)
% calculate center distance error and overlap
% seq_length = results.len;
seq_length = size(rect_anno, 1);
full_rect_anno = rect_anno; % for overlap success plot


if size(results, 1) ~= size(rect_anno, 1)
    results = results(1:size(rect_anno, 1), :);
end

%% calculation of Center Error
rect_mat = results;
% before evaluation, remove the frames where the target is absent -->
% for the calculation of Distance Precision
absent_idx = exist_anno == 0;
rect_mat(absent_idx, :)  = [];
rect_anno(absent_idx, :) = [];

% center position
% if length(rect_anno(0))
center_GT = [rect_anno(:,1)+(rect_anno(:,3)-1)/2 ...
             rect_anno(:,2)+(rect_anno(:,4)-1)/2];

center = [rect_mat(:,1)+(rect_mat(:,3)-1)/2 ...
          rect_mat(:,2)+(rect_mat(:,4)-1)/2];

% the new seq_length, since we remove the absent frames
new_seq_length = size(rect_anno, 1);
      
% % computer center distance
if norm_dst
    center(:, 1) = center(:, 1)./rect_anno(:, 3);
    center(:, 2) = center(:, 2)./rect_anno(:, 4);
    center_GT(:, 1) = center_GT(:, 1)./rect_anno(:, 3);
    center_GT(:, 2) = center_GT(:, 2)./rect_anno(:, 4);
end
err_center = sqrt(sum(((center(1:new_seq_length,:)-center_GT(1:new_seq_length,:)).^2),2));

index = rect_anno > 0;
idx   = (sum(index, 2)==4);

err_center(~idx) = -1;

%% calculate overlap score
overlapScore = zeros(seq_length,1);
for frame_id = 1:seq_length
    pred_flag = exist_flag(results(frame_id,:));
    gt_flag = exist_anno(frame_id);
    if pred_flag && gt_flag
        score = calc_iou(results(frame_id,:), full_rect_anno(frame_id,:));
    elseif (~pred_flag) && (~gt_flag)
        score = 1;
    else
        score = -1;
    end
    overlapScore(frame_id) = score;
end

end

function flag = exist_flag(pred)

    if numel(pred) ==0 || numel(pred) ==1 || (pred(1)==0 &&pred(3)==0)
        flag = 0;
    else 
        flag = 1;
    end
end

function iou = calc_iou(A, B)
    % A,B [x1, y1, w, h]
    leftA   = A(1);
    topA = A(2);
    rightA  = leftA + A(3);
    bottomA    = topA + A(4);

    leftB   = B(:,1);
    topB = B(:,2);
	rightB  = leftB + B(:,3);
    bottomB    = topB + B(:,4);
    
    % # get the overlap rectangle
    overlap_x1 = max(leftA, leftB);
    overlap_y1 = max(topA, topB);
    overlap_x2 = min(rightA, rightB);
    overlap_y2 = min(bottomA, bottomB);
	if overlap_x2 - overlap_x1 <= 0 || overlap_y2 - overlap_y1 <= 0
        iou = 0;
    else
       areaA   = A(3) .* A(4);
       areaB   = B(3) .* B(4);
       size_intersection = (overlap_x2 - overlap_x1) * (overlap_y2 - overlap_y1);
       iou = size_intersection / (areaA + areaB - size_intersection);
    end   
end
