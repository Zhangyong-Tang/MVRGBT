function eval_tracker(dataset, seqs, trackers, eval_type, name_tracker_all, tmp_mat_path, path_anno, rp_all, norm_dst)
% evaluate each tracker
num_tracker = numel(trackers);

threshold_set_overlap = 0:0.05:1;
threshold_set_error   = 0:50;
if norm_dst
    threshold_set_error = threshold_set_error / 100;
end

for i = 1:numel(seqs) % for each sequence
    s    = seqs{i};      % name of sequence
    
    % load GT and the absent flags
    switch dataset

        case 'MV-RGBT'
            try
                anno_rgb = dlmread([path_anno s '/' s '_1.txt']);
                anno_tir = dlmread([path_anno s '/' s '_1.txt']);
            catch
                anno_rgb = dlmread([path_anno s '/visible.txt']);
                anno_tir = dlmread([path_anno s '/infrared.txt']);
            end
            gtbbox_anno_rgb = anno_rgb;
            gtbbox_anno_tir = anno_tir;
            exist_anno = zeros(length(anno_rgb), 1);
            for frame=1: length(anno_rgb)
                ans = anno_rgb(frame,:);
                if ans(1) ~= 0
                    exist_anno(frame) = 1;
                else
                    exist_anno(frame) = 0;
%                     gtbbox_anno(frame,:)= [0,0,0,0];
                end
            end
        otherwise
            anno = loadjson([path_anno s '/IR_label.json']);
            gtbbox_anno = anno.gt_rect;
            exist_anno = anno.exist;
    end

    

    
    for k = 1:num_tracker  % evaluate each tracker
        t = trackers{k};   % name of tracker
        
        % load tracking result
        if strcmp(t.type, 'json')
            res_json = loadjson([rp_all t.name '/' s '.txt']);
            res = res_json.res;
        elseif strcmp(t.type, 'txt')
            res = dlmread([rp_all t.name '/' s '.txt']);
        else
            error('No such Type')
        end

        fprintf(['evaluating ' t.name ' on ' s ' ...\n']);
        
        success_num_overlap = zeros(1, numel(threshold_set_overlap));
        success_num_SR = zeros(1, numel(threshold_set_overlap));
        success_num_err     = zeros(1, numel(threshold_set_error));
        
        
        if isempty(res)
            break;
        end
        
        if length(res) < length(gtbbox_anno_rgb)
           gtbbox_anno_rgb =  gtbbox_anno_rgb(1:length(res), :);
           gtbbox_anno_tir =  gtbbox_anno_tir(1:length(res), :);
        elseif   length(res) > length(gtbbox_anno_tir)
            res = res(1:length(res), :);
        end
        
        [overlapScore1, err_center1] = calc_seq_err_robust(res, gtbbox_anno_rgb, exist_anno, norm_dst);  % not consider the absent frames
        [overlapScore2, err_center2] = calc_seq_err_robust(res, gtbbox_anno_tir, exist_anno, norm_dst);
        err_center = min(err_center1, err_center2);
        overlapScore = max(overlapScore1, overlapScore2);

        for t_idx = 1:numel(threshold_set_overlap)
            success_num_overlap(1, t_idx) = sum(overlapScore > threshold_set_overlap(t_idx));
        end
        
        for t_idx = 1:length(threshold_set_error)
            success_num_err(1, t_idx) = sum(err_center <= threshold_set_error(t_idx));
        end
        
        len_all = size(gtbbox_anno_rgb, 1);  % number of frames in the sequence
        ave_success_rate_plot(k, i, :)     = success_num_overlap/(len_all + eps);
        ave_success_rate_plot_err(k, i, :) = success_num_err/(len_all + eps);
    end
end

% save results
if ~exist(tmp_mat_path, 'dir')
    mkdir(tmp_mat_path);
end

dataName1 = [tmp_mat_path 'aveSuccessRatePlot_' num2str(num_tracker) 'alg_overlap_' eval_type '.mat'];
save(dataName1, 'ave_success_rate_plot', 'name_tracker_all');

dataName2 = [tmp_mat_path 'aveSuccessRatePlot_' num2str(num_tracker) 'alg_error_' eval_type '.mat'];
save(dataName2, 'ave_success_rate_plot_err', 'name_tracker_all');

end