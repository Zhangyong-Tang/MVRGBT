# MoETrack for RGB-T Tracking

Implementation of the paper “[Revisitng the RGBT Tracking Benchmarks from the Perspective of Modality Validity: A New Benchmark, Problem, and Solution]”

## Environment Installation
```
conda create -n MoETrack python=3.8
conda activate MoETrack
bash install.sh
```

## Project Paths Setup
Run the following command to set paths for this project
```
python tracking/create_default_local_file.py --workspace_dir . --data_dir ./data --save_dir ./output
```
After running this command, you can also modify paths by editing these two files
```
lib/train/admin/local.py  # paths about training
lib/test/evaluation/local.py  # paths about testing
```

## Data Preparation
Put the tracking datasets in `./data`. It should look like:
```
${PROJECT_ROOT}
  -- data
      -- lasher
          |-- trainingset
          |-- testingset
          |-- trainingsetList.txt
          |-- testingsetList.txt
          ...
```

