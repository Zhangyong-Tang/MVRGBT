from lib.test.evaluation.environment import EnvSettings

def local_env_settings():
    settings = EnvSettings()

    # Set your local paths here

    settings.davis_dir = ''
    settings.network_path = ''    # Where tracking networks are stored.
    settings.gtot_dir = ''
    settings.lasher_path = ''
    settings.UAV_RGBT_dir = ''
    settings.rgbt234_dir = ''
    settings.got10k_path = ''
    settings.rgbt210_dir = ''
    settings.got_reports_path = ''
    settings.lasot_lmdb_path = ''
    settings.lasot_path = ''
    settings.network_path = ''  # Where tracking networks are stored.
    settings.nfs_path = ''
    settings.otb_path = ''
    settings.prj_dir = ''
    settings.result_plot_path = ''
    settings.results_path = ''
    settings.save_dir = ''
    settings.mvrgbtdataset_dir = ''
    return settings

